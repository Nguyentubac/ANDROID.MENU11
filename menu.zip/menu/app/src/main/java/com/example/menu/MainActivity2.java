package com.example.menu;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.List;

public class MainActivity2 extends AppCompatActivity {
    ArrayList<String> mylist = new ArrayList<>();
    int pos;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main2);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        Button btnadd = findViewById(R.id.button1);
        Button btnup = findViewById(R.id.button2);
        Button btndel = findViewById(R.id.button3);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(MainActivity2.this, android.R.layout.simple_list_item_1,mylist);
        ListView lv = findViewById(R.id.lv1);
        lv.setAdapter(adapter);
        EditText txt1 = findViewById(R.id.editTextText);
        EditText txt2 = findViewById(R.id.editTextText2);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                pos = position;
                String aaa = mylist.get(pos).toString();
                String[] parts = aaa.split("-");
                String a = parts[0];
                String b = parts[1];
                txt1.setText(a);
                txt2.setText(b);
            }
        });
        btnadd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity2.this, txt1.getText().toString() , Toast.LENGTH_SHORT).show();
                if(!txt1.getText().toString().isEmpty() && !txt2.getText().toString().isEmpty()){
                    mylist.add(txt1.getText().toString() + "-" + txt2.getText().toString());
                    adapter.notifyDataSetChanged();
                }
                else {
                    Toast.makeText(MainActivity2.this, "Nhap lai", Toast.LENGTH_SHORT).show();
                }
            }
        });
        btnup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String ten = txt1.getText().toString();
                String cs = txt2.getText().toString();
                mylist.set(pos,ten + "-" + cs);
                adapter.notifyDataSetChanged();
            }
        });
        btndel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mylist.remove(pos);
                adapter.notifyDataSetChanged();
            }
        });
    }
}